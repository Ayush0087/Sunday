Insert into employee Values (1,'Mungeli chowk','Ayush Agrawal',-40000);
Insert into employee Values (2,'fubwaara chowk','LormiStar',50000000); 




 

INSERT INTO Question_Bank VALUES(1,'Mumbai','Raipur','Bhopal', 'Mumbai', 'Delhi', 'What Is Capital Of Maharashtra');










Insert into admin Values (101,'admin','admin@capgemini.com','Manager087'); 
Insert into candidate Values(1001, 'Ayush','ayush@capgemini.com', 'Ayush087');