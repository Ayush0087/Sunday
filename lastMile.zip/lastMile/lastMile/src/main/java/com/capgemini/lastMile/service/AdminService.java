package com.capgemini.lastMile.service;

import java.util.List;

import com.capgemini.lastMile.entity.Admin;
 
/**
 * @author JavaSolutionsGuide
 *
 */
public interface AdminService {
 public List<Admin> retrieveAdmins();
  
 public Admin getAdmin(Long adminId);
  
 public void saveAdmin(Admin  admin);
  
 public void deleteAdmin(Long adminId);
  
 public void updateAdmin(Admin admin);
}