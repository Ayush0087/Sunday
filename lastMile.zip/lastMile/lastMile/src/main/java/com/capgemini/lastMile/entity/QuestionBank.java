package com.capgemini.lastMile.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
 
/**
 * @author Ayush Agrawal
 *
 */

/**id: number;
questionID: string;
questionName: string;
option1: string;
option2: string;
option3: string;
option4: string;
lastModifiedDateTime: string;
creationDateTime: string;*/



@Entity
@Table(name="QuestionBank")
public class QuestionBank {
  
 @Id
 @GeneratedValue(strategy= GenerationType.IDENTITY)
 private Long id;
  
 @Column(name="Question_Name")
 private String questionName;
 
 
 @Column(name="OPTION1")
 private String option1;
  
 @Column(name="OPTION2")
 private String option2;
 
 @Column(name="OPTION3")
 private String option3;
 
 @Column(name="OPTION4")
 private String option4;
 
 @Column(name="ANSWER")
 private String answer;

public Long getId() {
	return id;
}

public void setId(Long id) {
	this.id = id;
}

public String getQuestionName() {
	return questionName;
}

public void setQuestionName(String questionName) {
	this.questionName = questionName;
}

public String getOption1() {
	return option1;
}

public void setOption1(String option1) {
	this.option1 = option1;
}

public String getOption2() {
	return option2;
}

public void setOption2(String option2) {
	this.option2 = option2;
}

public String getOption3() {
	return option3;
}

public void setOption3(String option3) {
	this.option3 = option3;
}

public String getOption4() {
	return option4;
}

public void setOption4(String option4) {
	this.option4 = option4;
}

public String getAnswer() {
	return answer;
}

public void setAnswer(String answer) {
	this.answer = answer;
}
 
 


 
 
 
 
 
 

 
 

}