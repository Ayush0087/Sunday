package com.capgemini.lastMile.service;

import java.util.List;

import com.capgemini.lastMile.entity.Candidate;
 
/**
 * @author JavaSolutionsGuide
 *
 */
public interface CandidateService {
 public List<Candidate> retrieveCandidates();
  
 public Candidate getCandidate(Long candidateId);
  
 public void saveCandidate(Candidate  candidate);
  
 public void deleteCandidate(Long candidateId);
  
 public void updateCandidate(Candidate candidate);
}