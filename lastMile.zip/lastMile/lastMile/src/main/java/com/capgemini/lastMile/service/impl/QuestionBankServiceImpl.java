package com.capgemini.lastMile.service.impl;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capgemini.lastMile.entity.QuestionBank;
import com.capgemini.lastMile.repository.QuestionBankRepository;
import com.capgemini.lastMile.service.QuestionBankService;
 
/**
 * @author Ayush Agrawal
 *
 */
@Service
public class QuestionBankServiceImpl implements QuestionBankService{
 
 @Autowired
 private QuestionBankRepository questionBankRepository;
 
 public void setQuestionBankRepository(QuestionBankRepository questionBankRepository) {
  this.questionBankRepository = questionBankRepository;
 }
  
 public List<QuestionBank> retrieveQuestionBanks() {
  List<QuestionBank> questionBanks = questionBankRepository.findAll();
  return questionBanks;
 }
  
 public QuestionBank getQuestionBank(Long questionBankId) {
  Optional<QuestionBank> optEmp = questionBankRepository.findById(questionBankId);
  return optEmp.get();
 }
  
 public void saveQuestionBank(QuestionBank questionBank){
	 questionBankRepository.save(questionBank);
 }
  
 public void deleteQuestionBank(Long questionBankId){
	 questionBankRepository.deleteById(questionBankId);
 }
  
 public void updateQuestionBank(QuestionBank questionBank) {
	 questionBankRepository.save(questionBank);
 }
}