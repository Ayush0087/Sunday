package com.capgemini.lastMile.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.lastMile.entity.Candidate;
import com.capgemini.lastMile.service.CandidateService;
 
/**
 * @author Ayush Agrawal
 *
 */
@RestController
public class CandidateRestController {
  
 @Autowired
 private CandidateService candidateService;
  
 public void setCandidateService(CandidateService candidateService) {
  this.candidateService = candidateService;
 }
 
 @GetMapping("/api/candidates/all")
 public List<Candidate> getcandidates() {
  List<Candidate> candidates = candidateService.retrieveCandidates();
  return candidates;
 }
  
 @GetMapping("/api/candidates/{candidateId}")
 public Candidate getCandidate(@PathVariable(name="candidateId")Long candidateId) {
  return candidateService.getCandidate(candidateId);
 }
  
 @PostMapping("/api/candidates")
 public void saveCandidate(Candidate candidate){
  candidateService.saveCandidate(candidate);
  System.out.println("Candidate Saved Successfully");
 }
  
 @DeleteMapping("/api/candidates/{candidateId}")
 public void deleteCandidate(@PathVariable(name="candidateId")Long candidateId){
  candidateService.deleteCandidate(candidateId);
  System.out.println("Candidate Deleted Successfully");
 }
  
 @PutMapping("/api/candidates/{candidateId}")
 public void updateCandidate(@RequestBody Candidate candidate,
   @PathVariable(name="candidateId")Long candidateId){
  Candidate emp = candidateService.getCandidate(candidateId);
  if(emp != null){
   candidateService.updateCandidate(candidate);
  }
   
 }
 
}