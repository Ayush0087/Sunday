package com.capgemini.lastMile.service.impl;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capgemini.lastMile.entity.Admin;
import com.capgemini.lastMile.repository.AdminRepository;
import com.capgemini.lastMile.service.AdminService;
 
/**
 * @author Ayush Agrawal
 *
 */
@Service
public class AdminServiceImpl implements AdminService{
 
 @Autowired
 private AdminRepository adminRepository;
 
 public void setAdminRepository(AdminRepository adminRepository) {
  this.adminRepository = adminRepository;
 }
  
 public List<Admin> retrieveAdmins() {
  List<Admin> admins = adminRepository.findAll();
  return admins;
 }
  
 public Admin getAdmin(Long adminId) {
  Optional<Admin> optAdmin = adminRepository.findById(adminId);
  return optAdmin.get();
 }
  
 public void saveAdmin(Admin admin){
  adminRepository.save(admin);
 }
  
 public void deleteAdmin(Long adminId){
  adminRepository.deleteById(adminId);
 }
  
 public void updateAdmin(Admin admin) {
  adminRepository.save(admin);
 }
}