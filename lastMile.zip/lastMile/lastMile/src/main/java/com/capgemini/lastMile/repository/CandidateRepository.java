package com.capgemini.lastMile.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.lastMile.entity.Candidate;
 
@Repository
public interface CandidateRepository extends JpaRepository<Candidate,Long>{
 
}