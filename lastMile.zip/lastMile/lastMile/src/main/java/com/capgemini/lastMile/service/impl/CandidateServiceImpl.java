package com.capgemini.lastMile.service.impl;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capgemini.lastMile.entity.Candidate;
import com.capgemini.lastMile.repository.CandidateRepository;
import com.capgemini.lastMile.service.CandidateService;
 
/**
 * @author Ayush Agrawal
 *
 */
@Service
public class CandidateServiceImpl implements CandidateService{
 
 @Autowired
 private CandidateRepository candidateRepository;
 
 public void setCandidateRepository(CandidateRepository candidateRepository) {
  this.candidateRepository = candidateRepository;
 }
  
 public List<Candidate> retrieveCandidates() {
  List<Candidate> candidates = candidateRepository.findAll();
  return candidates;
 }
  
 public Candidate getCandidate(Long candidateId) {
  Optional<Candidate> optCandidate = candidateRepository.findById(candidateId);
  return optCandidate.get();
 }
  
 public void saveCandidate(Candidate candidate){
  candidateRepository.save(candidate);
 }
  
 public void deleteCandidate(Long candidateId){
  candidateRepository.deleteById(candidateId);
 }
  
 public void updateCandidate(Candidate candidate) {
  candidateRepository.save(candidate);
 }
}