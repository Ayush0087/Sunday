package com.capgemini.lastMile.service;

import java.util.List;

import com.capgemini.lastMile.entity.QuestionBank;
 
/**
 * @author JavaSolutionsGuide
 *
 */
public interface QuestionBankService {
 public List<QuestionBank> retrieveQuestionBanks();
  
 public QuestionBank getQuestionBank(Long questionBankId);
  
 public void saveQuestionBank(QuestionBank questionBank);
 public void deleteQuestionBank(Long questionBankId);
  
 public void updateQuestionBank(QuestionBank questionBank);
}