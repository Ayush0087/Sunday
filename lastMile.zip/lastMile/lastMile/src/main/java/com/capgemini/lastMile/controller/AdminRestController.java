package com.capgemini.lastMile.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.lastMile.entity.Admin;
import com.capgemini.lastMile.service.AdminService;
 
/**
 * @author JavaSolutionsGuide
 *
 */
@RestController
public class AdminRestController {
  
 @Autowired
 private AdminService adminService;
  
 public void setAdminService(AdminService adminService) {
  this.adminService = adminService;
 }
 
 @GetMapping("/api/admins/all")
 public List<Admin> getadmins() {
  List<Admin> admins = adminService.retrieveAdmins();
  return admins;
 }
  
 @GetMapping("/api/admins/{adminId}")
 public Admin getEmployee(@PathVariable(name="adminId")Long adminId) {
  return adminService.getAdmin(adminId);
 }
  
 @PostMapping("/api/admins")
 public void saveAdmin(Admin admin){
  adminService.saveAdmin(admin);
  System.out.println("Admin Saved Successfully");
 }
  
 @DeleteMapping("/api/admins/{adminId}")
 public void deleteAdmin(@PathVariable(name="adminId")Long adminId){
  adminService.deleteAdmin(adminId);
  System.out.println("Admin Deleted Successfully");
 }
  
 @PutMapping("/api/admins/{adminId}")
 public void updateAdmin(@RequestBody Admin admin,
   @PathVariable(name="adminId")Long adminId){
  Admin emp = adminService.getAdmin(adminId);
  if(emp != null){
   adminService.updateAdmin(admin);
  }
   
 }
 
}