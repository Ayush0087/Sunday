package com.capgemini.lastMile.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.lastMile.entity.QuestionBank;
import com.capgemini.lastMile.service.QuestionBankService;
 
/**
 * @author JavaSolutionsGuide
 *
 */
@RestController
public class QuestionBankRestController {
  
 @Autowired
 private QuestionBankService questionBankService;
  
 public void setQuestionBankService(QuestionBankService questionBankService) {
  this.questionBankService= questionBankService;
 }
 
 @GetMapping("/api/questionBanks/all")
 public List<QuestionBank> getQuestionBanks() {
  List<QuestionBank> questionBank = questionBankService.retrieveQuestionBanks();
  return questionBank;
 }
  
 @GetMapping("/api/questionBanks/{questionBankId}")
 public QuestionBank getQuestionBank(@PathVariable(name="questionBankId")Long questionBankId) {
  return questionBankService.getQuestionBank(questionBankId);
 }
  
 @PostMapping("/api/questionBanks")
 public void saveQuestionBank(QuestionBank questionBank){
  questionBankService.saveQuestionBank(questionBank);
  System.out.println("QuestionBank Saved Successfully");
 }
  
 @DeleteMapping("/api/questionBanks/{questionBankId}")
 public void deleteQuestionBank(@PathVariable(name="questionBankId")Long questionBankId){
	 questionBankService.deleteQuestionBank(questionBankId);
  System.out.println("QuestionBank Deleted Successfully");
 }
  
 @PutMapping("/api/questionBanks/{questionBankId}")
 public void updateQuestionBank(@RequestBody QuestionBank questionBank,
   @PathVariable(name="questionBankId")Long questionBankId){
	 QuestionBank emp = questionBankService.getQuestionBank(questionBankId);
  if(emp != null){
	  questionBankService.updateQuestionBank(questionBank);
  }
   
 }
 
}