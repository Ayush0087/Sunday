package com.capgemini.lastMile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LastMileApplicationTests {

	@Test
	void contextLoads() {
	}

}
