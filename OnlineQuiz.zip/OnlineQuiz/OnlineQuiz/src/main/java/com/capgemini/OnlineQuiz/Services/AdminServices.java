package com.capgemini.OnlineQuiz.Services;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.OnlineQuiz.Models.Admin;
import com.capgemini.OnlineQuiz.repository.AdminRepository;
 

@Service
public class AdminServices {
 
    @Autowired
     AdminRepository repo1;
     
    public List<Admin> listAll() {
        return repo1.findAll();
    }
     
    public void save(Admin admin) {
        repo1.save(admin);
    }
     
    public Admin get(Integer id) {
        return repo1.findById(id).get();
    }
     
    public void delete(Integer id) {
        repo1.deleteById(id);
    }
}

