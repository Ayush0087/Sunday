package com.capgemini.OnlineQuiz.Controller;

import java.util.*;

import org.springframework.beans.factory.annotation.*;

 
import org.springframework.web.bind.annotation.*;

import com.capgemini.OnlineQuiz.Models.Candidate;
import com.capgemini.OnlineQuiz.Services.CandidateServices;
 
@RestController
public class  CandidateController {
 
    @Autowired
    private CandidateServices service;
    
    @GetMapping(value = "/candidates/all")
	public List<Candidate> list() {
	    return service.listAll();
	   }

        
     
    // RESTful API methods for Retrieval operations
     
    // RESTful API method for Create operation
     
    // RESTful API method for Update operation
     
    // RESTful API method for Delete operation
}