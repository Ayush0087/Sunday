package com.capgemini.OnlineQuiz.Models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="Admins")

public class Admin {

	

		
	 private Integer id;
	 
		private String name;
	    private double price;
	    
	    
	    
	    public Admin() {
	    }
	 
	    public Admin(Integer id, String name, double price) {
	        this.id = id;
	        this.name = name;
	        this.price = price;
	    }
	    

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    public Integer getId() {
	        return id;
	    }
	    
	    public String getname() {
	        return name;
	    }
	 
	    public double getprice() {
	        return price;
	    }
}
