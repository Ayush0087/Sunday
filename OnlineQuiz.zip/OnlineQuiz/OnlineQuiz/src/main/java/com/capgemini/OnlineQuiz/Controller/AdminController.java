package com.capgemini.OnlineQuiz.Controller;

import java.util.*;

import org.springframework.beans.factory.annotation.*;

 
import org.springframework.web.bind.annotation.*;

import com.capgemini.OnlineQuiz.Models.Admin;
import com.capgemini.OnlineQuiz.Services.AdminServices;
 
@RestController
public class AdminController {
 
    @Autowired
    private AdminServices service;
     
    
    @RequestMapping(value = "/admins/all")
  	public List<Admin> list() {
  	    return service.listAll();
  	   }
    @RequestMapping("/")
    public String home(){
        return "Hello World!";
    }
   
       
    // RESTful API methods for Retrieval operations
     
    // RESTful API method for Create operation
     
    // RESTful API method for Update operation
     
    // RESTful API method for Delete operation
}