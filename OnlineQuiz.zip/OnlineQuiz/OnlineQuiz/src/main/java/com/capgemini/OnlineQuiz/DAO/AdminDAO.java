package com.capgemini.OnlineQuiz.DAO;

public class AdminDAO {

}
