package com.capgemini.OnlineQuiz.Models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="Candidates")
public class Candidate {
	@Id


	 private Integer id;
	
	
	    private String name;
	    private double price;
	    
	    
	    
	    public Candidate() {
	    }
	 
	    public Candidate(Integer id, String name, double price) {
	        this.id = id;
	        this.name = name;
	        this.price = price;
	    }
	    

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    public Integer getId() {
	        return id;
	    }
	    public String getname() {
	        return name;
	    }
	 
	    public double getprice() {
	        return price;
	    }
}
