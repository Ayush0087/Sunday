package com.capgemini.OnlineQuiz.Exception;

public class CustomException {

}
