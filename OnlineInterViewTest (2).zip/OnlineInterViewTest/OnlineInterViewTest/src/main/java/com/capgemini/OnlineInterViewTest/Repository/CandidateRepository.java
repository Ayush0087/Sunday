package com.capgemini.OnlineInterViewTest.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.OnlineInterView.Models.Candidate;

public interface CandidateRepository extends JpaRepository<Candidate, Integer> {
 
}

