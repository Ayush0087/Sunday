package com.capgemini.OnlineTest.Controller;

public class Candidate {

}
