package com.capgemini.OnlineTest.Controller;

public class Admin {

}
