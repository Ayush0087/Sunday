package com.capgemini.OnlineInterViewTest.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.OnlineInterView.Models.Admin;

public interface AdminRepository extends JpaRepository<Admin, Integer> {
 
}