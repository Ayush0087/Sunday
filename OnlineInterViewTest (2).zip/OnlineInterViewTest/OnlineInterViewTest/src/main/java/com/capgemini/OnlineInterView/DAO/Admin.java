package com.capgemini.OnlineInterView.DAO;

public class Admin {

}
