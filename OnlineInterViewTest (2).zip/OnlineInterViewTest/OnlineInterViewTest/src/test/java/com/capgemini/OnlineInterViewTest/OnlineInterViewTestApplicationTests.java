package com.capgemini.OnlineInterViewTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineInterViewTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
