﻿using System;

namespace CarRental.Helpers
{
    public class Class1
    {
    }
}
