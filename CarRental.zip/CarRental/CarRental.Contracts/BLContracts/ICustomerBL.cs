using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CarRental.Entities;

namespace CarRental.Contracts.BLContracts
{
    //Developed By Ayush Agrawal
    //base Interface for Customer
    public interface ICustomerBL : IDisposable
    {
        Task<bool> AddCustomerBL(Customer newCustomer);
        Task<List<Customer>> GetAllCustomerBL();
        Task<Customer> GetCustomerByCustomerIDBL(int searchCustomerID);
        Task<List<Customer>> GetCustomerByVehicleIDBL( int VehicleID);
        Task<bool> UpdateCustomerBL(Customer updateCustomer);
        Task<bool> DeleteCustomerBL(int deleteCustomerID);
    }
}