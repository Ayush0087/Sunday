using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CarRental.Entities;

namespace CarRental.Contracts.BLContracts
{
    //Developed By Ayush Agrawal
    //base Interface for Reservation
    public interface IReservationBL : IDisposable
    {
        Task<(bool,Guid)> AddReservationBL(Reservations newReservation);
        Task<List<Reservations>> GetAllReservationBL();
        Task<Reservations> GetReservationByReservationIDBL(Guid searchReservationID);
        Task<List<Reservations>> GetReservationByCustomerIDBL( Guid CustomerID);
        Task<List<Reservations>> GetReservationByVehicleIDBL( Guid VehicleID);
        
        Task<bool> UpdateReservationBL(Reservations updateReservation);
        Task<bool> DeleteReservationBL(Guid deleteReservationID);
    }
}