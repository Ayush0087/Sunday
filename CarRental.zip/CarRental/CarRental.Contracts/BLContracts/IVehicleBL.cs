using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CarRental.Entities;

namespace CarRental.Contracts.BLContracts
{
    //Developed By Ayush Agrawal
    //base Interface for Vehicle
    public interface IVehicleBL : IDisposable
    {
        Task<(bool,Guid)> AddVehicleBL(Vehicle newVehicle);
        Task<List<Vehicle>> GetAllVehicleBL();
        Task<Vehicle> GetVehicleByVehicleIDBL(Guid searchVehicleID);
        Task<List<Vehicle>> GetVehicleByCustomerIDBL( Guid CustomerID);
        Task<List<Vehicle>> GetVehicleByReservationIDBL( Guid ReservationID);
        
        Task<bool> UpdateVehicleBL(Vehicle updateVehicle);
        Task<bool> DeleteVehicleBL(Guid deleteVehicleID);
    }
}