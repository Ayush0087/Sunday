using System;
using CarRental.Entities;
using System.Collections.Generic;
using System.IO;

namespace CarRental.Contracts.DALContracts
{
    public abstract class ReservationDALBase
    {
        protected static List<Reservations> reservationList = new List<Reservations>();
        public abstract bool AddReservationDAL(Reservations newReservations);
        public abstract List<Reservations> GetAllReservationDAL();
        public abstract Reservations GetReservationByReservationIDDAL(Guid searchReservationID);
        public abstract List<Reservations> GetReservationByVehicleIDDAL(Guid vehicleID);
        public abstract List<Reservations> GetReservationByCustomerIDDAL(Guid customerID);
        public abstract bool UpdateReservationDAL(Reservations updateReservation);
        public abstract bool DeleteReservationDAL(Guid deleteReservationID);  

    }
}