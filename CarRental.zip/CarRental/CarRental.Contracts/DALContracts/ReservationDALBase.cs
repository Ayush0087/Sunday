using System;
using CarRental.Entities;
using System.Collections.Generic;
using System.IO;

namespace CarRental.Contracts.DALContracts
{
    public abstract class ReservationDALBase
    {
        protected static List<Reservations> reservationList = new List<Reservations>();
        public abstract bool AddReservationDAL(Reservations newReservations);
        public abstract List<Reservations> GetAllReservationDAL();
        public abstract Reservations GetReservationByReservationIDDAL(int searchReservationID);
        public abstract List<Reservations> GetReservationByVehicleIDDAL(int vehicleID);
        public abstract List<Reservations> GetReservationByCustomerIDDAL(int customerID);
        public abstract bool UpdateReservationDAL(Reservations updateReservation);
        public abstract bool DeleteReservationDAL(int deleteReservationID);  

    }
}