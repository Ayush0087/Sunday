using System;
using CarRental.Entities;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace CarRental.Contracts.DALContracts
{
    public abstract class CustomerDALBase
    {
        protected static List<Customer> customerList = new List<Customer>();
        public abstract bool AddCustomerDAL(Customer newCustomer);
        public  abstract Task<List<Customer>> GetAllCustomerDAL();
        public abstract Task<Customer> GetCustomerByCustomerIDDAL(int searchCustomerID);
        public abstract List<Customer> GetCustomerByVehicleIDDAL(int vehicleID);
        public abstract bool UpdateCustomerDAL(Customer updateCustomer);
        public abstract bool DeleteCustomerDAL(int deleteCustomerID);  

    }
}