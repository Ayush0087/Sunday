using System;
using CarRental.Entities;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace CarRental.Contracts.DALContracts
{
    public abstract class CustomerDALBase
    {
        protected static List<Customer> customerList = new List<Customer>();
        public abstract bool AddCustomerDAL(Customer newCustomer);
        public  abstract Task<List<Customer>> GetAllCustomerDAL();
        public abstract Customer GetCustomerByCustomerIDDAL(string searchCustomerID);
        public abstract List<Customer> GetCustomerByVehicleIDDAL(Guid vehicleID);
        public abstract bool UpdateCustomerDAL(Customer updateCustomer);
        public abstract bool DeleteCustomerDAL(string deleteCustomerID);  

    }
}