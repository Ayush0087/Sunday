using System;
using CarRental.Entities;
using System.Collections.Generic;
using System.IO;

namespace CarRental.Contracts.DALContracts
{
    public abstract class CustomerDALBase
    {
        protected static List<Customer> customerList = new List<Customer>();
        public abstract (bool,Guid) AddCustomerDAL(Customer newCustomer);
        public abstract List<Customer> GetAllCustomerDAL();
        public abstract Customer GetCustomerByCustomerIDDAL(Guid searchCustomerID);
        public abstract List<Customer> GetCustomerByVehicleIDDAL(Guid vehicleID);
        public abstract bool UpdateCustomerDAL(Customer updateCustomer);
        public abstract bool DeleteCustomerDAL(Guid deleteCustomerID);  

    }
}