using System;
using CarRental.Entities;
using System.Collections.Generic;
using System.IO;

namespace CarRental.Contracts.DALContracts
{
    public abstract class VehicleDALBase
    {
        protected static List<Vehicle> vehicleList = new List<Vehicle>();
        public abstract (bool,Guid) AddVehicleDAL(Vehicle newVehicles);
        public abstract List<Vehicle> GetAllVehicleDAL();
        public abstract Vehicle GetVehicleByVehicleIDDAL(Guid searchVehicleID);
        public abstract List<Vehicle> GetVehicleByReservationIDDAL(Guid reservationID);
        public abstract List<Vehicle> GetVehicleByCustomerIDDAL(Guid customerID);
        public abstract bool UpdateVehicleDAL(Vehicle updateVehicle);
        public abstract bool DeleteVehicleDAL(Guid deleteVehicleID);  

    }
}