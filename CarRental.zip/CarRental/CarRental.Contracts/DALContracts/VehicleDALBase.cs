using System;
using CarRental.Entities;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
namespace CarRental.Contracts.DALContracts
{
    public abstract class VehicleDALBase
    {
        protected static List<Vehicle> vehicleList = new List<Vehicle>();
        public abstract bool AddVehicleDAL(Vehicle newVehicles);
        public abstract Task<List<Vehicle>> GetAllVehicleDAL();
        public abstract Task<Vehicle> GetVehicleByVehicleIDDAL(int searchVehicleID);
        public abstract List<Vehicle> GetVehicleByReservationIDDAL(int reservationID);
        public abstract List<Vehicle> GetVehicleByCustomerIDDAL(int customerID);
        public abstract bool UpdateVehicleDAL(Vehicle updateVehicle);
        public abstract bool DeleteVehicleDAL(int deleteVehicleID);  

    }
}