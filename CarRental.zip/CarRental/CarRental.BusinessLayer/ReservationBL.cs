using System;
using CarRental.DataAccessLayer;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using CarRental.Contracts.BLContracts;
using CarRental.Contracts.DALContracts;
using CarRental.Entities;
using CarRental.Helpers.ValidationAttributes;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;

namespace CarRental.BusinessLayer
{
   
 public class ReservationBL : IReservationBL, IDisposable
    {
        //fields
        ReservationDALBase reservationDAL;

        /// <summary>
        /// Constructor.
        /// </summary>
        public ReservationBL()
        {
            this.reservationDAL = new ReservationDAL();
        }

    //  protected async override Task<bool>Validate(Customer entityObject)
    //     {
    //         StringBuilder sb = new StringBuilder();
    //         bool valid = await base.Validate(entityObject);
    //          if (valid == false)
    //             throw new Exception(sb.ToString());
    //         return valid;
    //     }


     public async Task<bool> AddReservationBL(Reservations newReservation)
        {
            bool reservationAdded = false;
        
            try
            {
               
               
                    await Task.Run(() =>
                    {
                         
                        (reservationAdded) = reservationDAL.AddReservationDAL(newReservation);
                        reservationAdded = true;
                       
                    });
               

            }
            catch (Exception)
            {
                throw;
            }
            return (reservationAdded);
        }
         public async Task<List<Reservations>> GetAllReservationBL()
        {
            List<Reservations> reservationList = null;
            try
            {
                await Task.Run(() =>
                {
                    reservationList = reservationDAL.GetAllReservationDAL();
                });
            }
            catch (Exception)
            {
                throw;
            }
            return reservationList;
        }

        
        
        ///  Developed by Ayush Agrawal
        
        public async Task<Reservations> GetReservationByReservationIDBL(int searchReservationID)
        {
            Reservations matchingReservation = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingReservation = reservationDAL.GetReservationByReservationIDDAL(searchReservationID);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingReservation;
        }



        public async Task<List<Reservations>> GetReservationByVehicleIDBL(int VehicleID)
        {
           List<Reservations> matchingReservation = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingReservation = reservationDAL.GetReservationByVehicleIDDAL(VehicleID);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingReservation;
        }


          public async Task<List<Reservations>> GetReservationByCustomerIDBL(int CustomerID)
        {
           List<Reservations> matchingReservation = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingReservation = reservationDAL.GetReservationByCustomerIDDAL(CustomerID);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingReservation;
        }



        public async Task<bool> UpdateReservationBL(Reservations updateReservation)
        {
            bool reservationUpdated = false;
            try
            {
                if ((await GetReservationByReservationIDBL(updateReservation.ReservationID)) != null)
                {
                    this.reservationDAL.UpdateReservationDAL(updateReservation);
                    reservationUpdated = true;
                   
                }
            }
            catch (Exception)
            {
                throw;
            }
            return reservationUpdated;
        }

      
        public async Task<bool> DeleteReservationBL(int deleteReservationID)
        {
            bool reservationDeleted = false;
            try
            {
                await Task.Run(() =>
                {
                    reservationDeleted =reservationDAL.DeleteReservationDAL(deleteReservationID);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return reservationDeleted;
        }


         public void Dispose()
        {
            ((ReservationDAL)reservationDAL).Dispose();
        }
    }
    
}

 
