using System;
using CarRental.DataAccessLayer;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using CarRental.Contracts.BLContracts;
using CarRental.Contracts.DALContracts;
using CarRental.Entities;
using CarRental.Helpers.ValidationAttributes;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;

namespace CarRental.BusinessLayer
{
   
 public class VehicleBL : IVehicleBL, IDisposable
    {
        //fields
        VehicleDALBase vehicleDAL;

        /// <summary>
        /// Constructor.
        /// </summary>
        public VehicleBL()
        {
            this.vehicleDAL = new VehicleDAL();
        }

    //  protected async override Task<bool>Validate(Vehicle entityObject)
    //     {
    //         StringBuilder sb = new StringBuilder();
    //         bool valid = await base.Validate(entityObject);
    //          if (valid == false)
    //             throw new Exception(sb.ToString());
    //         return valid;
    //     }


     public async Task<bool> AddVehicleBL(Vehicle newVehicle)
        {
            bool vehicleAdded = false;
            
            try
            {
               
               
                    await Task.Run(() =>
                    {
                         
                        (vehicleAdded) = vehicleDAL.AddVehicleDAL(newVehicle);
                        vehicleAdded = true;
                       
                    });
               

            }
            catch (Exception)
            {
                throw;
            }
            return (vehicleAdded);
        }
         public async Task<List<Vehicle>> GetAllVehicleBL()
        {
            List<Vehicle> vehicleList = null;
            try
            {
                await Task.Run(() =>
                {
                    vehicleList = vehicleDAL.GetAllVehicleDAL();
                });
            }
            catch (Exception)
            {
                throw;
            }
            return vehicleList;
        }

        
        
        ///  Developed by Ayush Agrawal
        
        public async Task<Vehicle> GetVehicleByVehicleIDBL(Guid searchVehicleID)
        {
            Vehicle matchingVehicle = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingVehicle = vehicleDAL.GetVehicleByVehicleIDDAL(searchVehicleID);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingVehicle;
        }



        public async Task<List<Vehicle>> GetVehicleByReservationIDBL(Guid ReservationID)
        {
           List<Vehicle> matchingVehicle = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingVehicle = vehicleDAL.GetVehicleByReservationIDDAL(ReservationID);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingVehicle;
        }


          public async Task<List<Vehicle>> GetVehicleByCustomerIDBL(Guid CustomerID)
        {
           List<Vehicle> matchingVehicle = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingVehicle = vehicleDAL.GetVehicleByCustomerIDDAL(CustomerID);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingVehicle;
        }



        public async Task<bool> UpdateVehicleBL(Vehicle updateVehicle)
        {
            bool vehicleUpdated = false;
            try
            {
                if ((await GetVehicleByVehicleIDBL(updateVehicle.VehicleID)) != null)
                {
                    this.vehicleDAL.UpdateVehicleDAL(updateVehicle);
                    vehicleUpdated = true;
                   
                }
            }
            catch (Exception)
            {
                throw;
            }
            return vehicleUpdated;
        }


      
        public async Task<bool> DeleteVehicleBL(Guid deleteVehicleID)
        {
            bool vehicleDeleted = false;
            try
            {
                await Task.Run(() =>
                {
                    vehicleDeleted =vehicleDAL.DeleteVehicleDAL(deleteVehicleID);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return vehicleDeleted;
        }


         public void Dispose()
        {
            ((VehicleDAL)vehicleDAL).Dispose();
        }
    }
    
}

 
