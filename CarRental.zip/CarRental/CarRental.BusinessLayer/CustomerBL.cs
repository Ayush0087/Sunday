﻿using System;
using CarRental.DataAccessLayer;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using CarRental.Contracts.BLContracts;
using CarRental.Contracts.DALContracts;
using CarRental.Entities;
using CarRental.Helpers.ValidationAttributes;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;

namespace CarRental.BusinessLayer
{
   
 public class CustomerBL : ICustomerBL, IDisposable
    {
        //fields
        CustomerDALBase customerDAL;

        /// <summary>
        /// Constructor.
        /// </summary>
        public CustomerBL()
        {
            this.customerDAL = new CustomerDAL();
        }

    //  protected async override Task<bool>Validate(Customer entityObject)
    //     {
    //         StringBuilder sb = new StringBuilder();
    //         bool valid = await base.Validate(entityObject);
    //          if (valid == false)
    //             throw new Exception(sb.ToString());
    //         return valid;
    //     }


     public async Task<bool> AddCustomerBL(Customer newCustomer)
        {
            bool customerAdded = false;
            try
            {
               
               
                    await Task.Run(() =>
                    {
                         
                        (customerAdded) = customerDAL.AddCustomerDAL(newCustomer);
                        customerAdded = true;
                       
                    });
               

            }
            catch (Exception)
            {
                throw;
            }
            return (customerAdded);
        }
         public async Task<List<Customer>> GetAllCustomerBL()
        {
            List<Customer> customerList = null;
            try
            {
                
                    customerList = await customerDAL.GetAllCustomerDAL();
            
            }
            catch (Exception)
            {
                throw;
            }
            return customerList;
        }

        
        
        ///  Developed by Ayush Agrawal
        
        public async Task<Customer> GetCustomerByCustomerIDBL( string cid)
        {
            Customer matchingCustomer = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingCustomer = customerDAL.GetCustomerByCustomerIDDAL(cid);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingCustomer;
        }



        public async Task<List<Customer>> GetCustomerByVehicleIDBL(Guid VehicleID)
        {
           List<Customer> matchingCustomer = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingCustomer = customerDAL.GetCustomerByVehicleIDDAL(VehicleID);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingCustomer;
        }



        public async Task<bool> UpdateCustomerBL(Customer updateCustomer)
        {
            bool customerUpdated = false;
            try
            {
                if ((await GetCustomerByCustomerIDBL(updateCustomer.cid)) != null)
                {
                    this.customerDAL.UpdateCustomerDAL(updateCustomer);
                    customerUpdated = true;
                   
                }
            }
            catch (Exception)
            {
                throw;
            }
            return customerUpdated;
        }

      
        public async Task<bool> DeleteCustomerBL(string deleteCustomerID)
        {
            bool customerDeleted = false;
            try
            {
                await Task.Run(() =>
                {
                    customerDeleted =customerDAL.DeleteCustomerDAL(deleteCustomerID);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return customerDeleted;
        }


         public void Dispose()
        {
            ((CustomerDAL)customerDAL).Dispose();
        }
    }
    
}

 
