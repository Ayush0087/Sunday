using System;

namespace CarRental.MVC.Models
{
    public class VehicleViewModel
    {
        public int VehicleID { get; set; }
        public string Mileage{get;set;}
        public string Location{ get;set;}
        public string VehicleSize{ get;set;}
        public string Transmission{get;set;}
        public int CustomerID{get; set;}


    }
}
