using System;

namespace CarRental.MVC.Models
{
    public class VehicleViewModel
    {
        public Guid VehicleID { get; set; }
        public int Mileage{get;set;}
        public string Location{ get;set;}
        public string VehicleSize{ get;set;}
        public string Transmission{get;set;}
        public string CustomerID{get; set;}


    }
}
