using System;

namespace CarRental.MVC.Models
{
    public class ReservationViewModel
    {
        public Guid ReservationID{get; set;}
        public Guid CustomerID { get; set; }
        public Guid VehicleID{get;set;}
        public DateTime StartDate{ get;set;}
        public DateTime EndDate{ get;set;}


    }
}
