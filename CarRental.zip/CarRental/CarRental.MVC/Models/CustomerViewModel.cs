using System;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace CarRental.MVC.Models
{
    public class CustomerViewModel
    {
        public int cid { get; set; }
        [Required(ErrorMessage = "Name can not be Empty")]
        [RegularExpression("^[A-Za-z ]*$", ErrorMessage = "Person name should contain alphbets only")]
        [Display(Name = "First Name")]
        public string firstname{get;set;}


        [Required(ErrorMessage = "Name can not be Empty")]
        [RegularExpression("^[A-Za-z ]*$", ErrorMessage = "Person name should contain alphbets only")]
        [Display(Name = "Last Name")]
        public string lastname{ get;set;}

        [Required(ErrorMessage = "Address Line 2 can't be blank.")]
        [RegularExpression("^[A-Za-z -]{2,40}$", ErrorMessage = "Address  should contain Society, Village")]
        public string address{ get;set;}

        [Display(Name = "Email")]
         [Required(ErrorMessage = "Email can't be blank.")]
        [RegularExpression(@"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*", ErrorMessage = "Email is invalid.")]
        public string Email{get;set;}

        [Required(ErrorMessage = "Password can't be blank.")]
        [RegularExpression(@"((?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,15})", ErrorMessage = "Password should be 6 to 15 characters with at least one digit, one uppercase letter, one lower case letter.")]
        [Display(Name = "Password")]
        public string Password{get;set;}


         [Required(ErrorMessage = "Mobile No. Can not be blank")]
        [RegularExpression(@"^((\+)?(\d{2}[-]))?(\d{10}){1}?$", ErrorMessage = "10 digit Mobile Number")]
        [Display(Name = "Mobile Number")]
        public string MobileNumber {get; set;}

     


    }
}
