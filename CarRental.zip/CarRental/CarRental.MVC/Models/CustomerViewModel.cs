using System;

namespace CarRental.MVC.Models
{
    public class CustomerViewModel
    {
        public string cid { get; set; }
        public string firstname{get;set;}
        public string lastname{ get;set;}
        public string address{ get;set;}
        public string Email{get;set;}
        public string Password{get;set;}
        public string MobileNumber {get; set;}


    }
}
