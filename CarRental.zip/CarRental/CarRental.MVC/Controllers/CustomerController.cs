using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using CarRental.MVC.Models;
using CarRental.BusinessLayer;
using CarRental.Entities;
using CarRental.Contracts.BLContracts;
using CarRental.Contracts.DALContracts;
using System.Data;
using System.Net;
using System.Net.Http;

namespace CarRental.MVC.Controllers
{
    public class CustomerController : Controller
    {
    /// <summary>
    /// Created By Ayush grawal on 14/02/2020
    /// </summary>
         public  ActionResult Create()
        {
            CustomerViewModel customerViewModel = new CustomerViewModel();
         
          return View(customerViewModel);
                 
        }
              [HttpPost]
               public async Task<ActionResult> Create(CustomerViewModel customerVM)
            {
                try
                {
                    bool isAdded = false;
                    //Create object of CustomerBL
                    using (ICustomerBL customerBL = new CustomerBL())
                    {
                        //Creating Object of Entity Model
                        Customer customer = new Customer();
                        customer.firstname = customerVM.firstname;
                        customer.lastname = customerVM.lastname;
                        customer.address= customerVM.address;
                        Random r =new Random();
                        customer.cid=r.Next(100,10000);

                        (isAdded) = await customerBL.AddCustomerBL(customer);
                        if (isAdded)
                        {
                            
                            //Go to Index action method of Persons Controller
                            return RedirectToAction("Create", "Vehicle");
                        }
                        else
                        {
                            //Return plain html / plain string
                            return Content("Customer Not Added");
                        }
                    }

                }
                catch (Exception ex)
                {

                    return Content(ex.Message);
                }


            }


       
        public async Task<ActionResult> Index()
        {
            //DepartmentBL reference variable
           CustomerBL customerBL = new CustomerBL();


            //List of DepartmentViewModel
            List<CustomerViewModel> customerViewModel = new List<CustomerViewModel>();
            List<Customer> customers = await customerBL.GetAllCustomerBL();

            //foreach loop to convert Department into DepartmentViewModels
            foreach (var item in customers)
            {
               CustomerViewModel customerVM = new CustomerViewModel();
                //customerVM.CustomerID = item.CustomerID;
                customerVM.firstname = item.firstname;
                customerVM.lastname=item.lastname;
                customerVM.Email=item.Email;
                customerVM.MobileNumber=item.MobileNumber;
                customerVM.address=item.address;
                customerVM.Password=item.Password;
                customerVM.cid=item.cid;
                
                //adding the DepartmentViewModel to the List
               customerViewModel.Add(customerVM);

            }
            //return the list of the DepartmentViewModel
              return View(customerViewModel);
        }



       
          [Route("Customer/Edit")]
        public async Task<ActionResult> Edit(int cid)
        {
            try
            {
               
                //Create object of AddressBL
                using (ICustomerBL customerBL = new CustomerBL())
                {
                    Customer customer = await customerBL.GetCustomerByCustomerIDBL(cid);
                    //Creating Object of Entity MNodel
                     CustomerViewModel customerVM = new CustomerViewModel();
                    customerVM.firstname = customer.firstname;
                    customerVM.lastname = customer.lastname;
                    customerVM.address= customer.address;
                    customer.cid=customer.cid;
                   
                    return View(customerVM);
                   
                }
                

            }
            catch (Exception ex)
            {
               return Content(ex.Message);
            }

        }

      







         // URL:Customers/Edit  
         [HttpPost]
    //    [Route("Customer/Edit/{cid}")]
        
        public async Task<ActionResult> Edit1(CustomerViewModel customerVM)
        {
            try
            {
                bool isUpdated = false;
                  ICustomerBL customerBL = new CustomerBL();
                
                   Customer customer= new Customer();
                    //Creating and Inititalize view model
                        customer.firstname = customerVM.firstname;
                        customer.lastname = customerVM.lastname;
                        customer.address= customerVM.address;
                        customer.cid=customerVM.cid;
                    //calling BL and passing Intity  object to BL
                     isUpdated = await customerBL.UpdateCustomerBL(customer);
                    if(isUpdated)
                    {
                    
                        return RedirectToAction("Index", "Customer");
                    }
                    else
                    {
                       return Content("Customer Not Updated");
                    }
                
            }
            catch (Exception ex)
            {
                return Content(ex.Message);
            }

        }

        //Action method for Deleting Customer
       // URL: Retailers/Delete

        [Route("Customer/Delete/{cid}")]
        public async  Task<ActionResult> Delete(int cid)
        {
           bool isDeleted = false;
            try
            {// Creating object of Customer Bussiness layer
                using (ICustomerBL customerBL = new CustomerBL())
                {
                
                    
                    isDeleted = await customerBL.DeleteCustomerBL(cid);
                    if(isDeleted)
                    {
                        
                        return RedirectToAction("Index","Customer");
                    }
                    else
                    {
                        return Content("Customer not Deleted");
                    }
                }
                
            }
            catch (Exception ex)
            {
                return Content(ex.Message);
            }
        
          
        }



      
     }
}
