using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using CarRental.MVC.Models;
using CarRental.BusinessLayer;
using CarRental.Entities;
using CarRental.Contracts.BLContracts;
using CarRental.Contracts.DALContracts;
using System.Data;
using System.Net;
using System.Net.Http;

namespace CarRental.MVC.Controllers
{
    public class CustomerController : Controller
    {
    /// <summary>
    /// Created By Ayush grawal on 14/02/2020
    /// </summary>
         public  ActionResult Create()
        {
            CustomerViewModel customerViewModel = new CustomerViewModel();
         
          return View(customerViewModel);
                 
        }
         [HttpPost]
            public async Task<ActionResult> AddCustomer(CustomerViewModel customerVM)
            {
                try
                {
                    bool isAdded = false;
                    Guid CustomerID;
                    //Create object of CustomerBL
                    using (ICustomerBL customerBL = new CustomerBL())
                    {
                        //Creating Object of Entity Model
                        Customer customer = new Customer();
                        customer.FirstName = customerVM.FirstName;
                        customer.LastName = customerVM.LastName;
                        customer.Email = customerVM.Email;
                        customer.MobileNumber = customerVM.MobileNumber;
                        customer.Password = customerVM.Password;

                        (isAdded, CustomerID) = await customerBL.AddCustomerBL(customer);
                        if (isAdded)
                        {
                            
                            //Go to Index action method of Persons Controller
                            return RedirectToAction("Home", "");
                        }
                        else
                        {
                            //Return plain html / plain string
                            return Content("Account Not Added");
                        }
                    }

                }
                catch (Exception ex)
                {

                    return Content(ex.Message);
                }


            }


         //Action Result for INDEX
        public async Task<ActionResult> Index()
        {
            //CustomerBL reference variable
            CustomerBL customerBL = new CustomerBL();

            //List of CustomerViewModel
            List<CustomerViewModel> customerViewModel = new List<CustomerViewModel>();
            List<Customer> customers = await customerBL.GetAllCustomerBL();

            //foreach loop to convert Customer into customerViewModels
            foreach (var item in customers)
            {
                CustomerViewModel customerVM = new CustomerViewModel();
                customerVM.CustomerID = item.CustomerID;
                customerVM.FirstName = item.FirstName;
                customerVM.LastName=item.LastName;
                customerVM.Email=item.Email;
                customerVM.MobileNumber=item.MobileNumber;
                customerVM.Password=item.Password;
                
                //adding the CustomerViewModel to the List
                customerViewModel.Add(customerVM);

            }
            //return the list of the CustomerViewModel
            return View(customerViewModel);
        }

         // URL:Customers/Edit
        [HttpPost]
        
        public async Task<ActionResult> Edit(CustomerViewModel customerVM)
        {
            try
            {
                bool isUpdated = false;
                using (ICustomerBL customerBL = new CustomerBL())
                {
                   Customer customer= new Customer();
                    //Creating and Inititalize view model
                    customer.FirstName = customerVM.FirstName;
                    customer.LastName = customerVM.LastName;
                    customer.MobileNumber = customerVM.MobileNumber;
                    customer.Email= customerVM.Email;
                    customer.Password= customerVM.Password;

                    //calling BL and passing Intity  object to BL
                     isUpdated = await customerBL.UpdateCustomerBL(customer);
                    if(isUpdated)
                    {
                    
                        return RedirectToAction("Home", "");
                    }
                    else
                    {
                       return Content("Customer Not Updated");
                    }
                }
            }
            catch (Exception ex)
            {
                return Content(ex.Message);
            }

        }

        //Action method for Deleting Customer
        // URL: Retailers/Delete
        public async Task<ActionResult> Delete()
        {
            try
            {// Creating object of Customer Bussiness layer
                using (ICustomerBL customerBL = new CustomerBL())
                {
                
                    Customer customer= new Customer();
                    bool isDeleted = await customerBL.DeleteCustomerBL(customer.CustomerID);
                    if(isDeleted)
                    {
                        return RedirectToAction("Home","");
                    }
                    else
                    {
                        return Content("Account not Deleted");
                    }
                }
            }
            catch (Exception ex)
            {
                return Content(ex.Message);
            }
          
        }



      
     }
}



        

    
          

