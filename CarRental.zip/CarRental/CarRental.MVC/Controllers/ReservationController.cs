using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using CarRental.MVC.Models;
using CarRental.BusinessLayer;
using CarRental.Entities;
using CarRental.Contracts.BLContracts;
using CarRental.Contracts.DALContracts;
using System.Data;
using System.Net;
using System.Net.Http;


namespace CarRental.MVC.Controllers
{
    public class ReservationController : Controller
    {
    /// <summary>
    /// Created By Ayush grawal on 14/02/2020
    /// </summary>
         public  ActionResult Create()
        {
            ReservationViewModel reservationViewModel = new ReservationViewModel();
         
          return View(reservationViewModel);
                 
        }

         // URL: Reservation/Create
        [HttpPost]
        public async Task<ActionResult> Create(ReservationViewModel reservationVM)
        {
            try
             {
                //Getting reservation Detail 
                    bool isAdded = false;
                    Guid ReservationID;
                    //Create object of CustomerBL
                    using (IReservationBL reservationBL = new ReservationBL())
                    {
                    Reservations reservation = new Reservations();
                    reservation.VehicleID = reservationVM.VehicleID;
                    reservation.CustomerID= reservation.CustomerID;
                    reservation.StartDate=reservation.StartDate;
                    reservation.EndDate=reservation.EndDate;
                    (isAdded, ReservationID) = await reservationBL.AddReservationBL(reservation);
                        if (isAdded)
                        {
                            
                            //Go to Index action method of Persons Controller
                            return RedirectToAction("Home", "");
                        }
                        else
                        {
                            //Return plain html / plain string
                            return Content("Reservation Not Added");
                        }
              }
     
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.StackTrace);
               return Content(ex.Message);
            }
           
          
           
        }

      
            }
        }



        

    
          

