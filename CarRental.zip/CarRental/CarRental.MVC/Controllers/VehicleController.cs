using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using CarRental.MVC.Models;
using CarRental.BusinessLayer;
using CarRental.Entities;
using CarRental.Contracts.BLContracts;
using CarRental.Contracts.DALContracts;
using System.Data;
using System.Net;
using System.Net.Http;


namespace CarRental.MVC.Controllers
{
    public class VehicleController : Controller
    {
    /// <summary>
    /// Created By Ayush grawal on 14/02/2020
    /// </summary>
         public ActionResult Create()
        {
            VehicleViewModel vehicleViewModel = new VehicleViewModel();

            
            //Creating Object of Product BL
            // CustomerBL customerBL = new CustomerBL();
            // List<Customer> customers = new List<Customer>();
            // customers = await customerBL.GetAllCustomerBL();
            // ViewBag.CustomerList = new SelectList(customers, "CustomerID", "CustomerID");
            
            return View(vehicleViewModel);
         
          
                 
        }
        // URL: Vehicle/Create
        [HttpPost]
        public async Task<ActionResult> Create(VehicleViewModel vehicleVM)
        {
            try
             {
                //Getting vehicle Detail 
                    bool isAdded = false;
                    //Create object of VehicleBL
                    using (IVehicleBL vehicleBL = new VehicleBL())
                    {
                    Vehicle vehicle = new Vehicle();
                    vehicle.Mileage = vehicleVM.Mileage;
                    vehicle.Location= vehicleVM.Location;
                    vehicle.VehicleSize=vehicleVM.VehicleSize;
                    vehicle.Transmission= vehicleVM.Transmission;
                 
                    //vehicle.CustomerID=vehicleVM.CustomerID;
                      Random r =new Random();
                        vehicle.VehicleID=r.Next(100,10000);

                
                    
                   
                    (isAdded) = await vehicleBL.AddVehicleBL(vehicle);
                        if (isAdded)
                        {
                            
                            //Go to Index action method of Persons Controller
                            return RedirectToAction("Create", "Reservation");
                        }
                        else
                        {
                            //Return plain html / plain string
                            return Content("Vehicle Not Added");
                        }
              }
     
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.StackTrace);
               return Content(ex.Message);
            }
           
          
           
        }



        public async Task<ActionResult> Index()
        {
            //DepartmentBL reference variable
           VehicleBL vehicleBL = new VehicleBL();


            //List of DepartmentViewModel
            List<VehicleViewModel> vehicleViewModel = new List<VehicleViewModel>();
            List<Vehicle> vehicles = await vehicleBL.GetAllVehicleBL();

            //foreach loop to convert Department into DepartmentViewModels
            foreach (var item in vehicles)
            {
               VehicleViewModel vehicleVM = new VehicleViewModel();
               
                    vehicleVM.Mileage = item.Mileage;
                    vehicleVM.Location= item.Location;
                    vehicleVM.VehicleSize=item.VehicleSize;
                    vehicleVM.Transmission= item.Transmission;
                    vehicleVM.VehicleID= item.VehicleID;
                 
                
                //adding the DepartmentViewModel to the List
               vehicleViewModel.Add(vehicleVM);

            }
            //return the list of the DepartmentViewModel
              return View(vehicleViewModel);
        }



       
          [Route("Vehicle/Edit")]
        public async Task<ActionResult> Edit(int VehicleID)
        {
            try
            {
               
                //Create object of AddressBL
                using (IVehicleBL vehicleBL = new VehicleBL())
                {
                    Vehicle vehicle = await vehicleBL.GetVehicleByVehicleIDBL(VehicleID);
                    //Creating Object of Entity MNodel
                     VehicleViewModel vehicleVM = new VehicleViewModel();
                    vehicleVM.Mileage = vehicle.Mileage;
                    vehicleVM.Location = vehicle.Location;
                    vehicleVM.Transmission = vehicle.Transmission;
                    vehicleVM.VehicleSize= vehicle.VehicleSize;
                    vehicleVM.VehicleID= vehicle.VehicleID;

                
                   
                    return View(vehicleVM);
                   
                }
                

            }
            catch (Exception ex)
            {
               return Content(ex.Message);
            }

        }

      







         // URL:Vehicle/Edit  
         [HttpPost]
       // [Route("Vehicle/Edit/{vid}")]
        
        public async Task<ActionResult> Edit(VehicleViewModel vehicleVM)
        {
            try
            {
                bool isUpdated = false;
                  IVehicleBL vehicleBL = new VehicleBL();
                
                   Vehicle vehicle= new Vehicle();
                    //Creating and Inititalize view model
                        vehicle.Mileage = vehicleVM.Mileage;
                        vehicle.Location= vehicleVM.Location;
                        vehicle.Transmission= vehicleVM.Transmission;
                        vehicle.VehicleSize= vehicleVM.VehicleSize;
                        vehicle.VehicleID=vehicleVM.VehicleID;
                       
                    //calling BL and passing Intity  object to BL
                     isUpdated = await vehicleBL.UpdateVehicleBL(vehicle);
                    if(isUpdated)
                    {
                    
                        return RedirectToAction("Index", "Vehicle");
                    }
                    else
                    {
                       return Content("Vehicle Not Updated");
                    }
                
            }
            catch (Exception ex)
            {
                return Content(ex.Message);
            }

        }

        //Action method for Deleting Customer
       // URL: Retailers/Delete

        [Route("Vehicle/Delete/{vid}")]
        public async  Task<ActionResult> Delete(int vid)
        {
           bool isDeleted = false;
            try
            {// Creating object of Customer Bussiness layer
                using (IVehicleBL vehicleBL = new VehicleBL())
                {
                
                    
                    isDeleted = await vehicleBL.DeleteVehicleBL(vid);
                    if(isDeleted)
                    {
                        
                        return RedirectToAction("Index","Vehicle");
                    }
                    else
                    {
                        return Content("Vehicle not Deleted");
                    }
                }
                
            }
            catch (Exception ex)
            {
                return Content(ex.Message);
            }
        
          
        



      
     }




      
            }
        }


        

    
          

