using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using CarRental.MVC.Models;
using CarRental.BusinessLayer;
using CarRental.Entities;
using CarRental.Contracts.BLContracts;
using CarRental.Contracts.DALContracts;
using System.Data;
using System.Net;
using System.Net.Http;

namespace CarRental.MVC.Controllers
{
    public class VehicleController : Controller
    {
    /// <summary>
    /// Created By Ayush grawal on 14/02/2020
    /// </summary>
         public  ActionResult Create()
        {
            VehicleViewModel vehicleViewModel = new VehicleViewModel();
         
          return View(vehicleViewModel);
                 
        }
        // URL: Vehicle/Create
        [HttpPost]
        public async Task<ActionResult> Create(VehicleViewModel vehicleVM)
        {
            try
             {
                //Getting vehicle Detail 
                    bool isAdded = false;
                    Guid VehicleID;
                    //Create object of VehicleBL
                    using (IVehicleBL vehicleBL = new VehicleBL())
                    {
                    Vehicle vehicle = new Vehicle();
                    vehicle.Mileage = vehicleVM.Mileage;
                    vehicle.Location= vehicleVM.Location;
                    vehicle.VehicleSize=vehicleVM.VehicleSize;
                    vehicle.Transmission= vehicleVM.Transmission;
                    
                   
                    (isAdded,VehicleID) = await vehicleBL.AddVehicleBL(vehicle);
                        if (isAdded)
                        {
                            
                            //Go to Index action method of Persons Controller
                            return RedirectToAction("Home", "");
                        }
                        else
                        {
                            //Return plain html / plain string
                            return Content("Vehicle Not Added");
                        }
              }
     
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.StackTrace);
               return Content(ex.Message);
            }
           
          
           
        }

      
            }
        }


        

    
          

