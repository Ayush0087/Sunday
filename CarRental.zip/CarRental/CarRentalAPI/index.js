const express = require('express')
const bodyParser = require('body-parser')
const app = express()
const db = require('./query')
const vdb = require('./vehiclequery')
const rdb = require('./reservationquery')
const port = 3000

app.use(bodyParser.json())
app.use(
  bodyParser.urlencoded({
    extended: true,
  })
)

app.get('/', (request, response) => {
  response.json({ info: 'Node.js, Express, and Postgres API' })
})

app.get('/Customers', db.getCustomer)
app.get('/Reservation', rdb.getReservation)
app.get('/Vehicle', vdb.getVehicle)
app.get('/Customers/:cid', db.getCustomerById)
app.get('/Voters/:Email', db.getVoterByEmail)
app.get('/Voters/:Email/Password/:Password',db.getVoterByEmailandPassword)
app.post('/Customers', db.createCustomer)
app.post('/Reservations', rdb.createReservation)
app.post('/Vehicles', vdb.createVehicle)
app.put('/Customers/:cid', db.updateCustomer)
app.delete('/Customers/:cid', db.deleteCustomer)



app.listen(port, () => {
  console.log(`App running on port ${port}.`)
})