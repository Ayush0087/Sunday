const Pool = require('pg').Pool
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'postgres',
  password: 'Ayush087@',
  port: 5432,
})
const getVehicle = (request, response) => {
    pool.query('SELECT * FROM "CarRental1"."Vehicle" ORDER BY "vid" ASC', (error, results) => {
      if (error) {
        throw error
      }
      response.status(200).json(results.rows)
    })
  }

  const createVehicle = (request, response) => {
    const { VehicleID,Mileage,Location,VehicleSize,Transmission} = request.body
  
    pool.query('Insert into "CarRental1"."Vehicle" ("vid","mileage", "location","vsize","transmission") values ($1,$2,$3,$4,$5)', [VehicleID,Mileage,Location,VehicleSize,Transmission], (error, results) => {
      if (error) {
        throw error
      } 
      response.status(201).send('')
    })
  }

  module.exports={
    getVehicle,
    createVehicle,
  }