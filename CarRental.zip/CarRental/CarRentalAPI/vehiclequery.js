const Pool = require('pg').Pool
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'postgres',
  password: 'Ayush087@',
  port: 5432,
})
const getVehicle = (request, response) => {
    pool.query('SELECT * FROM "CarRental"."Vehicle" ORDER BY "VehicleID" ASC', (error, results) => {
      if (error) {
        throw error
      }
      response.status(200).json(results.rows)
    })
  }

  const createVehicle = (request, response) => {
    const { Mileage,Location,VehicleSize,Transmission,CustomerID } = request.body
  
    pool.query('Insert into "CarRental"."Vehicle" ("VehicleID","Mileage", "Location","VehicleSize","Transmission", "CustomerID") values ($1,$2,$3,$4,$5,$6)', [Mileage,Location,VehicleSize,Transmission,CustomerID], (error, results) => {
      if (error) {
        throw error
      } 
      response.status(201).send('')
    })
  }

  module.exports={
    getVehicle,
    createVehicle,
  }