const Pool = require('pg').Pool
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'postgres',
  password: 'Ayush087@',
  port: 5432,
})
const getCustomer = (request, response) => {
  pool.query('SELECT * FROM "CarRental1"."Customers"', (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).json(results.rows)
  })
}

const getCustomerById = (request, response) => {
  const cid = parseInt(request.params.cid)
  pool.query('SELECT * FROM "CarRental1"."Customers" WHERE "cid" = $1', [cid], (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).json(results.rows)
  })
}

const getVoterByEmail = (request, response) => {
  const Email = request.params.Email
  pool.query('SELECT * FROM "Voters" WHERE "Email" = $1', [Email], (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).json(results.rows)
  })
}
const getVoterByEmailandPassword = (request, response) => {
  const Email = request.params.Email
  const Password= request.params.Password
  pool.query('SELECT * FROM "Voters" WHERE "Email" = $1 and "Password"=$2', [Email,Password], (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).json(results.rows)
  })
}
const createCustomer = (request, response) => {
  const { firstname,lastname,address,cid } = request.body

  pool.query('Insert into "CarRental1"."Customers" ("firstname", "lastname","address","cid") values ($1,$2,$3,$4)', [firstname,lastname,address,cid], (error, results) => {
    if (error) {
      throw error
    } 
    response.status(201).send('')
  })
}






const updateCustomer = (request, response) => {
  const cid = parseInt(request.params.cid)
  const { firstname, lastname, address } = request.body

  pool.query(
    'UPDATE "CarRental1"."Customers" SET firstname = $1, lastname = $2 , address= $3 WHERE cid = $4',
    [firstname, lastname, address, cid],
    (error, results) => {
      if (error) {
        throw error
      }
      response.status(200).send(`Customer modified with id: ${cid}`)
    }
  )
}

const deleteCustomer = (request, response) => {
  const cid = parseInt(request.params.cid)

  pool.query('DELETE FROM "CarRental1"."Customers" WHERE "cid" = $1', [cid], (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).send(`Customer deleted with ID: ${cid}`)
  })
}

module.exports = {
  getCustomer,
  getCustomerById,
  createCustomer,
  updateCustomer,
  deleteCustomer,
  getVoterByEmail,
  getVoterByEmailandPassword,
}