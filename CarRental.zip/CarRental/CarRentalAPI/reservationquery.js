const Pool = require('pg').Pool
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'postgres',
  password: 'Ayush087@',
  port: 5432,
})
const getReservation = (request, response) => {
    pool.query('SELECT * FROM "CarRental"."Reservation" ORDER BY "ReservationID" ASC', (error, results) => {
      if (error) {
        throw error
      }
      response.status(200).json(results.rows)
    })
  }

  const createReservation = (request, response) => {
    const { CustomerID,VehicleID,StartDate,EndDate } = request.body
  
    pool.query('Insert into "CarRental"."Reservation" ("ReservationID","CustomerID", "VehicleID","StartDate","EndDate") values ($1,$2,$3,$4,$5)', [CustomerID,VehicleID,StartDate,EndDate], (error, results) => {
      if (error) {
        throw error
      } 
      response.status(201).send('')
    })
  }

  module.exports={
    getReservation,
    createReservation
  }