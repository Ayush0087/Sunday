﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using CarRental.Entities;
using CarRental.Contracts.DALContracts;
using CarRental.Helpers;

namespace CarRental.DataAccessLayer
{
    
  
     public class CustomerDAL : CustomerDALBase,IDisposable
     {
        public override (bool, Guid) AddCustomerDAL(Customer newCustomer)
        {
            // SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);
            try
            {

                bool customerAdded = false;
                Guid CustomerGuid;
                try
                {
                    CustomerGuid = Guid.NewGuid();
                    newCustomer.CustomerID = CustomerGuid;
                 using (CarRentalEntities db = new CarRentalEntities())
                    {
                        db.Customer.Add(newCustomer);
                        db.SaveChanges();
                        customerAdded = true;

                    }

                }
                catch (Exception)
                {
                    throw;
                }
                return (customerAdded, CustomerGuid);
            }
            catch (Exception)
            {
                throw;
            }
        }

          public override List<Customer> GetAllCustomerDAL()
        {
            List<Customer> matchingCustomer = new List<Customer>();
            try
            {
                using (CarRentalEntities db = new CarRentalEntities())
                {
                    matchingCustomer = db.Customers.ToList();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return matchingCustomer;
        }

        public override Customer GetCustomerByCustomerIDDAL(Guid searchCustomerID)
        {
            Customer matchingCustomer = null;

            try
            {
                using (CarRentalEntities db = new CarRentalEntities())
                {
                    matchingCustomer = db.Customers.Where(a => a.CustomerID == searchCustomerID).FirstOrDefault();
                }

            }
            catch (Exception)
            {
                throw;
            }
            return matchingCustomer;
        }


        public override List<Customer> GetCustomerByVehicleIDDAL(Guid VehicleID)
        {
            List<Customer> matchingCustomer = new List<Customer>();
           
            try
            {
                using (CarRentalEntities db = new CarRentalEntities())
                {
                    matchingCustomer = db.Customers.Where(a => a.VehicleID == VehicleID).ToList();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return matchingCustomer;
        }


        public override bool UpdateCustomerDAL(Customer updateCustomer)
        {
            using (CarRentalEntities db = new CarRentalEntities())
            {
                bool customerUpdated = false;
                try
                {

                 Customer matchingCustomer = db.Customers.Where(a => a.CustomerID == updateCustomer.CustomerID).FirstOrDefault();

                    if (matchingCustomer != null)
                    {
                        ReflectionHelpers.CopyProperties(updateCustomer, matchingCustomer, new List<string>() { "FirstName", "LastName", "Email", "MobileNumber", "Password" });
                        db.SaveChanges();
                       customerUpdated = true;
                    }

                }
                catch (Exception)
                {
                    throw;
                }
                return customerUpdated;
            }
        }

        
        public override bool DeleteCustomerDAL(Guid deleteCustomerID)
        {
           
            bool addressDeleted = false;
            try
            {
                using (CarRentalEntities db = new CarRentalEntities())
                {
                    int isdeleted = db.DeleteCustomer(deleteCustomerID);

                    if (isdeleted > 0)
                    { addressDeleted = true; }
                    else
                    { addressDeleted = false; }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return addressDeleted;
        }

        public void Dispose()
        {
            //No unmanaged resources currently
        }
   }
}
