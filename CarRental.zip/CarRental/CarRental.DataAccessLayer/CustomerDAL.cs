﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using CarRental.Entities;
using CarRental.Contracts.DALContracts;
using CarRental.Helpers;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Net.Http.Headers;
using Newtonsoft.Json;


namespace CarRental.DataAccessLayer
{
    
  
   public static class HttpClientExtensions
    {
        public static Task<HttpResponseMessage> PostAsJsonAsync<T>(
            this HttpClient httpClient, string url, T data)
        {
            var dataAsString = JsonConvert.SerializeObject(data);
            var content = new StringContent(dataAsString);
            content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            return httpClient.PostAsync(url, content);
        }


         public static Task<HttpResponseMessage> PutAsJsonAsync<T>(
            this HttpClient httpClient, string url, T data)
        {
            var dataAsString = JsonConvert.SerializeObject(data);
            var content = new StringContent(dataAsString);
            content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            return httpClient.PutAsync(url, content);
        }

        public static async Task<T> ReadAsJsonAsync<T>(this HttpContent content)
        {
            var dataAsString = await content.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<T>(dataAsString);
        }

          }
     public class CustomerDAL : CustomerDALBase,IDisposable
     {
        public  override bool AddCustomerDAL(Customer newCustomer)
        {
            
               bool isAdded= false;
            // SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);
              try
            {
                //Getting retailer Detail from session

                using (var client = new HttpClient())
                {
                   
                    //Creating Object of Entity MNodel
                    Customer customer = new Customer();
                    customer.firstname= newCustomer.firstname;
                    customer.lastname= newCustomer.lastname;
                    customer.address= newCustomer.address;
                    customer.cid=newCustomer.cid;
                  
                    client.BaseAddress = new Uri("http://localhost:3000/");
                    //HTTP POST
                    var postTask = client.PostAsJsonAsync<Customer>("Customers", customer);
                    postTask.Wait();

                    var result = postTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        isAdded= true;
                        return isAdded;
                    }
                    else
                    {
                        //Return plain html / plain string
                        return isAdded;
                    }
                }
     
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.StackTrace);
               return isAdded;
            }
        }

       

         public  override async Task<List<Customer>> GetAllCustomerDAL()
        {
              List<Customer> matchingCustomer = new List<Customer>();

             try
            {
                
              
                // using HttpClint for sending fet request
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:3000");
                    //HTTP GET
                    var responseTask = client.GetAsync("Customers");
                    responseTask.Wait();

                    //assinging result
                    var result = responseTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        //reding data from content
                        var readTask = await result.Content.ReadAsJsonAsync<IList<Customer>>();
                        

                        //assinging the data to address view model by converting IQueyable to List
                        matchingCustomer = readTask.ToList();
                    }
                    else //web api sent error response
                    {
                        //log response status here..

                        matchingCustomer = Enumerable.Empty<Customer>().ToList();

                    }
               }
                return matchingCustomer;
                
            }
            catch (Exception)
            {
                throw;

            }
        }
            

            
            
        

        public async override Task<Customer> GetCustomerByCustomerIDDAL(int searchCustomerID)
        {
            Customer matchingCustomer = new Customer();
              try
            {
                
              
                // using HttpClint for sending fet request
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:3000");
                    //HTTP GET
                    var responseTask = client.GetAsync($"/Customers/{searchCustomerID}");
                    responseTask.Wait();

                    //assinging result
                    var result = responseTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        //reding data from content
                        var readTask = await result.Content.ReadAsJsonAsync<IList<Customer>>();
                        

                        //assinging the data to address view model by converting IQueyable to List
                        List<Customer> matchingCustomers=  readTask.ToList();
                        matchingCustomer = matchingCustomers[0];
                    }
                    
               }
                return matchingCustomer;
                
            }
            catch (Exception)
            {
                throw;

            }

           
        
        }


        public override List<Customer> GetCustomerByVehicleIDDAL(int VehicleID)
        {
            List<Customer> matchingCustomer = new List<Customer>();
           
            
            return matchingCustomer;
        }


        public override bool UpdateCustomerDAL(Customer updateCustomer)
        {
          
             bool isUpdated= false;
     
           try
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:3000/");

                
                    var putTask = client.PutAsJsonAsync<Customer>($"Customers/{updateCustomer.cid}", updateCustomer);
                   putTask.Wait();

                   var result = putTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                          isUpdated=true;
                        return isUpdated;
                    }
                      else
                    {
                        //Return plain html / plain string
                     return isUpdated;
                    }
                }
               
            }
            
          catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.StackTrace);
               return isUpdated;
            }
        }

        

      
        public override bool DeleteCustomerDAL(int cid)
        {
           
             try
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:3000/");
                    //HTTP DELETE
                    var deleteTask = client.DeleteAsync($"/Customers/{cid}");
                    deleteTask.Wait();
                    var result = deleteTask.Result;
                    // when result of IsSuccessStatusCode is true
                   
                }
                return true;
            }
            catch (Exception)
            {
                //returning system error message
                throw;
            }
        }

        public void Dispose()
        {
            //No unmanaged resources currently
        }
   }
}