using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using CarRental.Entities;
using CarRental.Contracts.DALContracts;
using CarRental.Helpers;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Net.Http.Headers;
using Newtonsoft.Json;

namespace CarRental.DataAccessLayer
{
    
  
     public class ReservationDAL : ReservationDALBase,IDisposable
     {

       
       
       public override bool AddReservationDAL(Reservations newReservation)
        {
            
            bool isAdded= false;
          
             try
            {
                //Getting retailer Detail from session

                using (var client = new HttpClient())
                {
                   
                    //Creating Object of Entity MNodel
                   Reservations reservations = new Reservations();
                    reservations.VehicleID = newReservation.VehicleID;
                    reservations.CustomerID= newReservation.CustomerID;
                    reservations.StartDate=newReservation.StartDate;
                    reservations.EndDate=newReservation.EndDate;
                  
                    client.BaseAddress = new Uri("http://localhost:3000/");
                    //HTTP POST
                    var postTask = client.PostAsJsonAsync<Reservations>("Reservation", reservations);
                    postTask.Wait();

                    var result = postTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        isAdded= true;
                        return isAdded;
                    }
                    else
                    {
                        //Return plain html / plain string
                        return isAdded;
                    }
                }
     
            }
             catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.StackTrace);
               return isAdded;
            }
        }


          public override List<Reservations> GetAllReservationDAL()
        {
            List<Reservations> matchingReservation = new List<Reservations>();
            
            return matchingReservation;
        }

        public override Reservations GetReservationByReservationIDDAL(Guid searchReservationID)
        {
            Reservations matchingReservation = null;

            
            return matchingReservation;
        }


        public override List<Reservations> GetReservationByVehicleIDDAL(Guid VehicleID)
        {
            List<Reservations> matchingReservation = new List<Reservations>();
           
            
            return matchingReservation;
        }

        public override List<Reservations> GetReservationByCustomerIDDAL(Guid CustomerID)
        {
            List<Reservations> matchingReservation = new List<Reservations>();
           
           
            return matchingReservation;
        }



        public override bool UpdateReservationDAL(Reservations updateReservation)
        {
            
                bool reservationUpdated = false;
               
                return reservationUpdated;
        }

        
        public override bool DeleteReservationDAL(Guid deleteReservationID)
        {
           
            bool reservationDeleted = false;
           
            return reservationDeleted;
        }

        public void Dispose()
        {
            //No unmanaged resources currently
        }
   }
}
