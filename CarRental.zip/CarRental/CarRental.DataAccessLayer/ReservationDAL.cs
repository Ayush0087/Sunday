using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using CarRental.Entities;
using CarRental.Contracts.DALContracts;
using CarRental.Helpers;

namespace CarRental.DataAccessLayer
{
    
  
     public class ReservationDAL : ReservationDALBase,IDisposable
     {
        public override (bool, Guid) AddReservationDAL(Reservations newReservation)
        {
            // SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);
            try
            {

                bool reservationAdded = false;
                Guid ReservationGuid;
                try
                {
                    ReservationGuid = Guid.NewGuid();
                    newReservation.ReservationID = ReservationGuid;
                 using (CarRentalEntities db = new CarRentalEntities())
                    {
                        db.Reservation.Add(newReservation);
                        db.SaveChanges();
                        reservationAdded = true;

                    }

                }
                catch (Exception)
                {
                    throw;
                }
                return (reservationAdded, ReservationGuid);
            }
            catch (Exception)
            {
                throw;
            }
        }

          public override List<Reservations> GetAllReservationDAL()
        {
            List<Reservations> matchingReservation = new List<Reservations>();
            try
            {
                using (CarRentalEntities db = new CarRentalEntities())
                {
                    matchingReservation = db.Reservation.ToList();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return matchingReservation;
        }

        public override Reservations GetReservationByReservationIDDAL(Guid searchReservationID)
        {
            Reservations matchingReservation = null;

            try
            {
                using (CarRentalEntities db = new CarRentalEntities())
                {
                    matchingReservation = db.Reservation.Where(a => a.ReservationID == searchReservationID).FirstOrDefault();
                }

            }
            catch (Exception)
            {
                throw;
            }
            return matchingReservation;
        }


        public override List<Reservations> GetReservationByVehicleIDDAL(Guid VehicleID)
        {
            List<Reservations> matchingReservation = new List<Reservations>();
           
            try
            {
                using (CarRentalEntities db = new CarRentalEntities())
                {
                    matchingReservation = db.Reservation.Where(a => a.VehicleID == VehicleID).ToList();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return matchingReservation;
        }

        public override List<Reservations> GetReservationByCustomerIDDAL(Guid CustomerID)
        {
            List<Reservations> matchingReservation = new List<Reservations>();
           
            try
            {
                using (CarRentalEntities db = new CarRentalEntities())
                {
                    matchingReservation = db.Reservation.Where(a => a.CustomerID == CustomerID).ToList();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return matchingReservation;
        }



        public override bool UpdateReservationDAL(Reservations updateReservation)
        {
            using (CarRentalEntities db = new CarRentalEntities())
            {
                bool reservationUpdated = false;
                try
                {

                 Reservations matchingReservation = db.Reservation.Where(a => a.ReservationID == updateReservation.ReservationID).FirstOrDefault();

                    if (matchingReservation != null)
                    {
                        ReflectionHelpers.CopyProperties(updateReservation, matchingReservation, new List<string>() { "StartDate", "EndDate"});
                        db.SaveChanges();
                       reservationUpdated = true;
                    }

                }
                catch (Exception)
                {
                    throw;
                }
                return reservationUpdated;
            }
        }

        
        public override bool DeleteReservationDAL(Guid deleteReservationID)
        {
           
            bool reservationDeleted = false;
            try
            {
                using (CarRentalEntities db = new CarRentalEntities())
                {
                    int isdeleted = db.DeleteReservation(deleteReservationID);

                    if (isdeleted > 0)
                    { reservationDeleted = true; }
                    else
                    { reservationDeleted = false; }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return reservationDeleted;
        }

        public void Dispose()
        {
            //No unmanaged resources currently
        }
   }
}
