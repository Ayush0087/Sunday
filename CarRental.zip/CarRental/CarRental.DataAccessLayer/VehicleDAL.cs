using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using CarRental.Entities;
using CarRental.Contracts.DALContracts;
using CarRental.Helpers;

namespace CarRental.DataAccessLayer
{
    
  
     public class VehicleDAL : VehicleDALBase,IDisposable
     {
        public override (bool, Guid) AddVehicleDAL(Vehicle newVehicle)
        {
            // SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);
            try
            {

                bool vehicleAdded = false;
                Guid VehicleGuid;
                try
                {
                    VehicleGuid = Guid.NewGuid();
                    newVehicle.VehicleID = VehicleGuid;
                 using (CarRentalEntities db = new CarRentalEntities())
                    {
                        db.Vehicle.Add(newVehicle);
                        db.SaveChanges();
                        vehicleAdded = true;

                    }

                }
                catch (Exception)
                {
                    throw;
                }
                return(vehicleAdded, VehicleGuid);
            }
            catch (Exception)
            {
                throw;
            }
        }

          public override List<Vehicle> GetAllVehicleDAL()
        {
            List<Vehicle> matchingVehicle = new List<Vehicle>();
            try
            {
                using (CarRentalEntities db = new CarRentalEntities())
                {
                    matchingVehicle = db.Vehicle.ToList();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return matchingVehicle;
        }

        public override Vehicle GetVehicleByVehicleIDDAL(Guid searchVehicleID)
        {
            Vehicle matchingVehicle = null;

            try
            {
                using (CarRentalEntities db = new CarRentalEntities())
                {
                    matchingVehicle = db.Vehicles.Where(a => a.VehicleID == searchVehicleID).FirstOrDefault();
                }

            }
            catch (Exception)
            {
                throw;
            }
            return matchingVehicle;
        }


        public override List<Vehicle> GetVehicleByReservationIDDAL(Guid ReservationID)
        {
            List<Vehicle> matchingVehicle = new List<Vehicle>();
           
            try
            {
                using (CarRentalEntities db = new CarRentalEntities())
                {
                    matchingVehicle = db.Vehicles.Where(a => a.ReservationID == ReservationID).ToList();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return matchingVehicle;
        }

        public override List<Vehicle> GetVehicleByCustomerIDDAL(Guid CustomerID)
        {
            List<Vehicle> matchingVehicle = new List<Vehicle>();
           
            try
            {
                using (CarRentalEntities db = new CarRentalEntities())
                {
                    matchingVehicle = db.Vehicles.Where(a => a.CustomerID == CustomerID).ToList();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return matchingVehicle;
        }



        public override bool UpdateVehicleDAL(Vehicle updateVehicle)
        {
            using (CarRentalEntities db = new CarRentalEntities())
            {
                bool vehicleUpdated = false;
                try
                {

                 Vehicle matchingVehicle = db.Vehicles.Where(a => a.VehicleID == updateVehicle.VehicleID).FirstOrDefault();

                    if (matchingVehicle != null)
                    {
                        ReflectionHelpers.CopyProperties(updateVehicle, matchingVehicle, new List<string>() { "Mileage", "Location","VehicleSize","Transmission"});
                        db.SaveChanges();
                       vehicleUpdated = true;
                    }

                }
                catch (Exception)
                {
                    throw;
                }
                return vehicleUpdated;
            }
        }

        
        public override bool DeleteVehicleDAL(Guid deleteVehicleID)
        {
           
            bool vehicleDeleted = false;
            try
            {
                using (CarRentalEntities db = new CarRentalEntities())
                {
                    int isdeleted = db.DeleteVehicle(deleteVehicleID);

                    if (isdeleted > 0)
                    { vehicleDeleted = true; }
                    else
                    { vehicleDeleted = false; }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return vehicleDeleted;
        }

        public void Dispose()
        {
            //No unmanaged resources currently
        }
   }
}
