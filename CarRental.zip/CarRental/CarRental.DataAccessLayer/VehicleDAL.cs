using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using CarRental.Entities;
using CarRental.Contracts.DALContracts;
using CarRental.Helpers;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Net.Http.Headers;
using Newtonsoft.Json;


namespace CarRental.DataAccessLayer
{
    
  
     public class VehicleDAL : VehicleDALBase,IDisposable
     {
      

        public override bool AddVehicleDAL(Vehicle newVehicle)
       {
            
            bool isAdded= false;
          
             try
            {
                //Getting retailer Detail from session

                using (var client = new HttpClient())
                {
                   
                    //Creating Object of Entity MNodel
                    Vehicle vehicle =new Vehicle();
                    vehicle.CustomerID = newVehicle.CustomerID;
                    vehicle.VehicleSize= newVehicle.VehicleSize;
                    vehicle.Transmission= newVehicle.Transmission;
                    vehicle.Location= newVehicle.Location;
                    vehicle.Mileage= newVehicle.Mileage;
                    
                  
                    client.BaseAddress = new Uri("http://localhost:3000/");
                    //HTTP POST
                    var postTask = client.PostAsJsonAsync<Vehicle>("Vehicles", vehicle);
                    postTask.Wait();

                    var result = postTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        isAdded= true;
                        return isAdded;
                    }
                    else
                    {
                        //Return plain html / plain string
                        return isAdded;
                    }
                }
     
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.StackTrace);
               return isAdded;
            }
        }

          public override List<Vehicle> GetAllVehicleDAL()
        {
            List<Vehicle> matchingVehicle = new List<Vehicle>();
           
            return matchingVehicle;
        }

        public override Vehicle GetVehicleByVehicleIDDAL(Guid searchVehicleID)
        {
            Vehicle matchingVehicle = null;

           
            return matchingVehicle;
        }


        public override List<Vehicle> GetVehicleByReservationIDDAL(Guid ReservationID)
        {
            List<Vehicle> matchingVehicle = new List<Vehicle>();
           
            
            return matchingVehicle;
        }

        public override List<Vehicle> GetVehicleByCustomerIDDAL(Guid CustomerID)
        {
            List<Vehicle> matchingVehicle = new List<Vehicle>();
           
           
            return matchingVehicle;
        }



        public override bool UpdateVehicleDAL(Vehicle updateVehicle)
        {
           
                bool vehicleUpdated = false;
               
                return vehicleUpdated;
            
        }

        
        public override bool DeleteVehicleDAL(Guid deleteVehicleID)
        {
           
            bool vehicleDeleted = false;
           
            return vehicleDeleted;
        }

        public void Dispose()
        {
            //No unmanaged resources currently
        }
   }
}
