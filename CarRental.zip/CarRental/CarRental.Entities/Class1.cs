﻿using System;

namespace CarRental.Entities
{
    public class Class1
    {
    }
}
