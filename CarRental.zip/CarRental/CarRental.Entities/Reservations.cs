﻿  using System;
  using System.Collections.Generic;
namespace CarRental.Entities
{
    using System;
    public class Reservations
    {
         public int ReservationID{get; set;}
        public int CustomerID { get; set; }
        public int VehicleID{get;set;}
        public DateTime StartDate{ get;set;}
        public DateTime EndDate{ get;set;}


    }
}
