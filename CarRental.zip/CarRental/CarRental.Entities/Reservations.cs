﻿  using System;
  using System.Collections.Generic;
namespace CarRental.Entities
{
    using System;
    public class Reservations
    {
         public Guid ReservationID{get; set;}
        public Guid CustomerID { get; set; }
        public Guid VehicleID{get;set;}
        public DateTime StartDate{ get;set;}
        public DateTime EndDate{ get;set;}


    }
}
