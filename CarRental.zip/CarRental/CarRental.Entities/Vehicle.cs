  using System;
  using System.Collections.Generic;
namespace CarRental.Entities
{
    using System;
    public class Vehicle
    {
       public int VehicleID { get; set; }
        public string Mileage{get;set;}
        public string Location{ get;set;}
        public string VehicleSize{ get;set;}

        public string Transmission{get;set;}

        public int CustomerID{get;set;}
    }
}
